// // var employees = new Array();
// var employees = new Array(3);

// employees[0] = "ABC";
// employees[1] = "AAC";
// employees[2] = "ACC";
// employees[3] = "CCC";

// console.log(employees.length);
// console.log(employees);

var employees = [
    { id: 1, name: "Manish", city: "Pune" },
    { id: 2, name: "Neeraj", city: "Delhi" },
    { id: 3, name: "Pravin", city: "Pune" }
];

// console.log(employees.length);

// for (let i = 0; i < employees.length; i++) {
//     console.log(`${i}       ${employees[i].name}`);
// }

// for(const key in employees){
//     console.log(`${key}       ${employees[key].name}`);
// }

// ES 2015 - ForOf Loop
// for(const item of employees){
//     console.log(`${item.name}`);
// }

for(const [index, item] of employees.entries()){
    console.log(`${index} ${item.name}`);
}