// // Creates a new object, using an existing object as the prototype of the newly created object.

// let source = { id: 1, name: "Manish", address: { city: "Pune" } };

// const newSource1 = Object.assign({}, source);
// const newSource2 = Object.create(source);

// console.log(source);
// console.log(newSource1);
// console.log(newSource2);

// --------------------------

let source = { id: 1, name: "Manish", address: { state: "MH" } };

// Object.preventExtensions(source);
// Object.freeze(source);
Object.seal(source);

// if (Object.isExtensible(source))
source.city = "Pune";

// if (!Object.isFrozen())
// source.id = 100;

if (!Object.isSealed(source))
    delete source.id;

console.log(source);