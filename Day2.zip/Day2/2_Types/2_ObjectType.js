// var toy1 = new Object();
// console.log(toy1);
// console.log(typeof toy1);

// console.log(toy1.toString());
// console.log(toy1.id);

var toy1 = new Object();
// toy1.color = "red";

Object.prototype.color = "red"

console.log(toy1.color);

var toy2 = new Object();
console.log(toy2.color);
