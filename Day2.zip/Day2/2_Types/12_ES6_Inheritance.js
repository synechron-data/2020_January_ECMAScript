class Vehicle {
    constructor(m) {
        this._make = m || "Honda";
    }

    start() {
        return `${this._make}, engine started`
    }
}

class FourWheeler extends Vehicle {
    constructor(mk) {
        super(mk);
    }
}

var v = new FourWheeler("Ford");
console.log(v.start());