// const Counter = (function(){
//     function Counter(interval) {
//         this._count = 0;
//         this._interval = interval || 1;
//     }

//     Counter.prototype.next = function () {
//         return this._count += this._interval;
//     }

//     Counter.prototype.prev = function () {
//         return this._count -= this._interval;
//     }

//     return Counter;
// })();

class Counter {
    constructor(interval) {
        this._count = 0;
        this._interval = interval || 1;
    }

    next() {
        return this._count += this._interval;
    }

    prev() {
        return this._count -= this._interval;
    }
}

var cnt = new Counter();
console.log(cnt.next());
console.log(cnt.next());
console.log(cnt.prev());
console.log(cnt.next());
console.log("\n\n");
var cnt5 = new Counter(5);
console.log(cnt5.next());
console.log(cnt5.next());
console.log(cnt5.prev());
console.log(cnt5.next());