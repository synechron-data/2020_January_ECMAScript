class Person {
    constructor(name) {
        this._name = name;
        this._city = "NA";
    }

    get Name() {
        return this._name;
    }

    set Name(name) {
        this._name = name;
    }

    get City() {
        return this._city;
    }

    set City(value) {
        this._city = value;
    }
}

var p1 = new Person("Manish");
console.log(p1.Name);
p1.Name = "Abhijeet";
p1.City = "Pune";
console.log(p1.Name);
console.log(p1.City);

