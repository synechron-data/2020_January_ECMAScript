// Case 1 - Default Import
// import square from './lib';
// console.log("Result: ", square(20));

// import sqr from './lib';
// console.log("Result: ", sqr(20));

// Case 2 - Multi Import
// import square, { check } from './lib';
// console.log("Result: ", square(20));
// console.log("Result: ", check(20));

// import sqr, { check } from './lib';
// console.log("Result: ", sqr(20));
// console.log("Result: ", check(20));

// Case 3 - Named Imports
// import { square, check } from './lib';
// console.log("Result: ", square(20));
// console.log("Result: ", check(20));

import * as lib from './lib';
console.log("Result: ", lib.square(20));
console.log("Result: ", lib.check(20));