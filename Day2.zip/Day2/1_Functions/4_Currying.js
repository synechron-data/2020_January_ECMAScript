// // function greetings(message, name) {
// //     console.log(`${message}, ${name}`);
// // }

// // greetings("Good Morning", "Abhijeet");
// // greetings("Good Morning", "Ramakant");
// // greetings("Good Morning", "Pravin");


// function Converter(toUnit, factor, offset, input) {
//     return [((offset + input) * factor).toFixed(2), toUnit].join("");
// }

// // console.log(Converter(' km', 1.6, 0, 10));

// // console.log(Converter(' INR', 70, 0, 100));
// // console.log(Converter(' INR', 70, 0, 125));
// // console.log(Converter(' INR', 70, 0, 600));
// // console.log(Converter(' INR', 70, 0, 945));

// var usdToInr = Converter.bind(undefined, ' INR', 70, 0);
// console.log(usdToInr(100));
// console.log(usdToInr(120));
// console.log(usdToInr(600));
// console.log(usdToInr(940));

// ------------------------------------------

function Converter(toUnit, factor, offset) {
    return function (input) {
        return [((offset + input) * factor).toFixed(2), toUnit].join("");
    }
}

var usdToInr = Converter(' INR', 70, 0);
console.log(usdToInr(100));
console.log(usdToInr(120));
console.log(usdToInr(600));
console.log(usdToInr(940));

