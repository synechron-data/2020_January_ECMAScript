'use strict'
// var count = 0;

// function next() {
//     return count += 1;
// }

// console.log(next());
// count = "ABC";
// console.log(next());
// console.log(next());

// -----------------------------------
// function next() {
//     var count = 0;
//     return count += 1;
// }

// console.log(next());
// console.log(next());
// console.log(next());

//--------------------------------------

// var next = (function () {
//     var count = 0;

//     return function () {
//         return count += 1;
//     }
// })();

// console.log(next());
// console.log(next());
// console.log(next());

// --------------------------------------

// var counter = (function () {
//     var count = 0;

//     return {
//         next: function () {
//             return count += 1;
//         },
//         prev: function () {
//             return count -= 1;
//         }
//     };
// })();

// console.log(counter.next());
// console.log(counter.next());
// console.log(counter.prev());
// console.log(counter.next());

// -------------------------------------

function getCounter(interval = 1) {
    var count = 0;

    return {
        next: function () {
            return count += interval;
        },
        prev: function () {
            return count -= interval;
        }
    };
};

var cnt = getCounter();
console.log(cnt.next());
console.log(cnt.next());
console.log(cnt.prev());
console.log(cnt.next());
console.log("\n\n");
var cnt5 = getCounter(5);
console.log(cnt5.next());
console.log(cnt5.next());
console.log(cnt5.prev());
console.log(cnt5.next());