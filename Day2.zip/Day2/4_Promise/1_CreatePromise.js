// var promise = new Promise((resolve, reject) => {
//     setInterval(() => {
//         console.log("Executed...");
//         resolve("This is Success Call");
//         // reject("This is Error Call");
//     }, 2000);
// });

// promise.then((m) => {
//     console.log("Success - ", m);
// }, (m) => {
//     console.log("Rejected - ", m);
// });

// Dev 1
function getString() {
    var promise = new Promise((resolve, reject)=>{
        const strArr = ['NodeJS', 'ReactJS', 'AngularJS', 'ExtJS', 'VueJS'];
        setInterval(() => {
            var str = strArr[Math.floor(Math.random() * strArr.length)];
            resolve(str);
        }, 2000);
    });

    return promise;
}

// Dev 2
var p = getString();
p.then(function (s) {
    console.log(s);
});