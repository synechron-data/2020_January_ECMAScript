var count = 1;

function Person() {
    this._id = count++;

    this.setId = function (id) {
        this._id = id;
    }

    this.getId = function () {
        return this._id;
    }
}

var p1 = new Person();
p1.setId(10);
console.log(p1.getId())

// var p2 = new Person();
// console.log(p2);

// 1. Creates a new instance (p) (HEAP)
// 2. Set p.__proto__ to Person.prototype
// 3. Person.call(p)