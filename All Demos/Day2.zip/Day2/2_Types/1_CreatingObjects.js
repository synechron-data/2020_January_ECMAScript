// var obj1 = new Object();
// console.log(obj1);
// console.log(typeof obj1);

// var obj2 = null;
// console.log(obj2);
// console.log(typeof obj2);

// // Object Literal
// var obj3 = {};
// console.log(obj3);
// console.log(typeof obj3);

// JavaScript Objects - Object Literal
var person = {
    id: 1,
    name: "Manish",
    display: function () {
        console.log(this);
    }
};

// person.display();

console.log(person);
console.log(JSON.stringify(person));
