var calculator = (function () {
    function Add(x, y) {
        return x + y;
    }

    function Sub(x, y) {
        return x - y;
    }

    function Mul(x, y) {
        return x * y;
    }

    function Div(x, y) {
        return x / y;
    }

    return {
        Add, Sub, Mul, Div
    };
})();

// console.log(calculator);
// console.log(calculator.Add(2, 5));
// console.log(calculator.Sub(2, 5));

// var Add = calculator.Add;
// var Sub = calculator.Sub;

// Object Destructuring
// var { Add, Sub } = calculator;
// console.log(Add(2, 5));
// console.log(Sub(2, 5));

// Array Destructuring

var arr = [10, 20, 30, 40, 50, 60];

// var x = arr[0];
// var y = arr[1];
// console.log(x, y);
// console.log("x = " + x + ", y = " + y);

// ES 2015 
// var [x, , y] = arr;
// console.log(`x = ${x}, y = ${y}`); //Template Literal

// var message = `Hello 

//         Manish`;
// console.log(message);

var [x, , y] = arr;
console.log(`Before, x = ${x}, y = ${y}`);

[x, y] = [y, x];

console.log(`After, x = ${x}, y = ${y}`);