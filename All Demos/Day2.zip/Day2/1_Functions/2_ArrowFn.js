function Add1(x, y) {
    return x + y;
}

var Add2 = function (x, y) {
    return x + y;
}

var Add3 = (x, y) => {
    return x + y;
}

var Add4 = (x, y) => x + y;

console.log(Add1(23, 45));
console.log(Add2(23, 45));
console.log(Add3(23, 45));
console.log(Add4(23, 45));