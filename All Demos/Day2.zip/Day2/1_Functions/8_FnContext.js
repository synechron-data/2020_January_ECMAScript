function Person(a) {
    var self = this;

    self.age = a;

    self.growOld = function () {
        console.log(this);
        self.age += 1;
    }
}

var p = new Person(20);

setInterval(p.growOld, 2000);

setInterval(function () {
    console.log(p.age);
}, 2000)

// function Person(a) {
//     this.age = a;

//     this.growOld = function () {
//         console.log(this);
//         this.age += 1;
//     }
// }

// var p = new Person(20);

// setInterval(p.growOld.bind(p), 2000);

// setInterval(function () {
//     console.log(p.age);
// }, 2000)

// var p = new Person(20);
// console.log(p.age);
// p.growOld();
// p.growOld();
// p.growOld();
// console.log(p.age);
