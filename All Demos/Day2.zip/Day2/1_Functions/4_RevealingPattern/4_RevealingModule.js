var calculator = (function () {
    function Add(x, y) {
        return x + y;
    }

    function Sub(x, y) {
        return x - y;
    }

    function Mul(x, y) {
        return x * y;
    }

    function Div(x, y) {
        return x / y;
    }

    // return {
    //     Addtion: Add,
    //     Subtract: Sub,
    //     Multiply: Mul
    // };

    // return {
    //     Add: Add,
    //     Sub: Sub,
    //     Mul: Mul
    // };

    // ES 2015 - Object Literal - Shortcut
    return {
        Add, Sub, Mul
    };
})();

// console.log(calculator);
console.log(calculator.Add(2, 4));
console.log(calculator.Sub(2, 4));
console.log(calculator.Mul(2, 4));