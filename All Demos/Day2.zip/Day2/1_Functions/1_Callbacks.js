// Pull
// // Dev 1
// function getString() {
//     const strArr = ['NodeJS', 'ReactJS', 'AngularJS', 'ExtJS', 'Angular'];
//     let str = strArr[Math.floor(Math.random() * strArr.length)];
//     return str;
// }

// // Dev 2
// setInterval(function () {
//     console.log(getString());
// }, 2000);

// Push
// Dev 1
function getString(cb) {
    const strArr = ['NodeJS', 'ReactJS', 'AngularJS', 'ExtJS', 'Angular'];
    setInterval(function () {
        let str = strArr[Math.floor(Math.random() * strArr.length)];
        cb(str);
    }, 2000);
}

// Dev 2
// function getStringCallback(s) {
//     console.log(s);
// }

// getString(getStringCallback);

// getString(function (s) {
//     console.log(s);
// });

// ES 2015 - Arrow Functions
getString((s) => {
    console.log(s);
});

// document.getElementById("b1").addEventListener("click", function(){});