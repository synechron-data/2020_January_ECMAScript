// Developer 2

var dev2;

(function (ns) {
    function Check() {
        console.log("Check from File 2");
    }

    ns.Check = Check;
})(dev2 = dev2 || {});
