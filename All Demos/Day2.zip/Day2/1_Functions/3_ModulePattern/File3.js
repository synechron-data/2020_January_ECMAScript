// Developer3

var dev1;

(function (ns) {
    function Test() {
        console.log("Test from File 3");
    }

    ns.Test = Test;
})(dev1 = dev1 || {});
