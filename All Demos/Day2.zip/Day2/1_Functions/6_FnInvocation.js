// function hello(){
//     console.log("Hello World!");
//     console.log(this);
// }

// hello();
// hello.call();
// hello.apply();

// var e1 = {
//     id: 1,
//     name: "Manish",
//     display: function () {
//         console.log(this);
//     }
// }

// var e2 = {
//     id: 2,
//     name: "Abhijeet",
//     display: function () {
//         console.log(this);
//     }
// }

// e1.display();
// e2.display();


function display(x, y) {
    console.log(this);
    console.log(x, y);
}

var e1 = {
    id: 1,
    name: "Manish"
}

var e2 = {
    id: 2,
    name: "Abhijeet"
}

// display();

// display.call(e1);
// display.call(e2);

// display.apply(e1);
// display.apply(e2);

// display.call(e1, 2, 4);
// display.apply(e1, [2, 4]);

e1.display = display.bind(e1);
e2.display = display.bind(e2);
// e1.display(23, 45);

console.log(e1);