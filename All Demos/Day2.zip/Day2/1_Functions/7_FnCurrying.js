// function greetings(message, name) {
//     console.log(`${message}, ${name}`);
// }

// greetings("Good Morning", "Manish");
// greetings("Good Morning", "Abhijeet");
// greetings("Good Morning", "Ramakant");

// function greetings(message) {
//     return function (name) {
//         console.log(`${message}, ${name}`);
//     }
// }
// var mGreet = greetings("Good Morning");

// var mGreet = greetings.bind(this,"Good Morning");
// mGreet("Manish");
// mGreet("Abhijeet");
// mGreet("Ramakant");

function Converter(toUnit, factor, offset, input) {
    return [((offset + input) * factor).toFixed(2), toUnit].join("");
}

// var kms = Converter(' km', 1.6, 0, 10);
// console.log(kms);

// var kms = Converter(' km', 1.6, 0, 34);
// console.log(kms);

var MilesToKmConverter = Converter.bind(this, ' km', 1.6, 0);
console.log(MilesToKmConverter(10));
console.log(MilesToKmConverter(20));
console.log(MilesToKmConverter(100));

var PoundsToKgConverter = Converter.bind(this,' kg', 0.45460, 0);
console.log(PoundsToKgConverter(10));
console.log(PoundsToKgConverter(5));

var FToCConverter = Converter.bind(this,' deg C', 0.5556, -32);
console.log(FToCConverter(98));