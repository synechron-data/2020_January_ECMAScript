// Case 1 - Default Export
// export default function sqaure(x) {
//     return x * x;
// }

// Case 2 - Multiple Exports - Named Exports
// export function sqaure(x) {
//     return x * x;
// }

// export function check(x) {
//     return `${x} is checked`;
// }

// Case 3 - Named and Default
export default function sqaure(x) {
    return x * x;
}

export function check(x) {
    return `${x} is checked`;
}