// Case 1 - Default Import
// import sqaure from './lib.js';
// console.log(sqaure(23));

// import sqr from './lib.js';
// console.log(sqr(23));

// Case 2 - Multiple Exports - Named Imports
// import { sqaure, check } from './lib.js'
// console.log(sqaure(23));
// console.log(check(23));

// import * as lib from './lib.js'
// console.log(lib.sqaure(23));
// console.log(lib.check(23));

// Case 3 - Named and Default
import square, { check } from './lib.js'
console.log(square(23));
console.log(check(23));


// rollup main.js --output.format iife --output.file bundle.js