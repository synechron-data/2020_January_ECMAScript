(function () {
    'use strict';

    // Case 1 - Default Export
    // export default function sqaure(x) {
    //     return x * x;
    // }

    // Case 2 - Multiple Exports - Named Exports
    // export function sqaure(x) {
    //     return x * x;
    // }

    // export function check(x) {
    //     return `${x} is checked`;
    // }

    // Case 3 - Named and Default
    function sqaure(x) {
        return x * x;
    }

    function check(x) {
        return `${x} is checked`;
    }

    // Case 1 - Default Import
    console.log(sqaure(23));
    console.log(check(23));

}());
