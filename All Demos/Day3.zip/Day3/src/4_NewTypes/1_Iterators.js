class Queue {
    constructor() {
        this._data = [];
    }

    push(n) {
        this._data[this._data.length] = n;
    }

    pop() {
        return this._data.shift();
    }

    *[Symbol.iterator]() {
        yield* this._data;
    }

    // *[Symbol.iterator]() {
    //     for (let i = 0; i < this._data.length; i++) {
    //         yield this._data[i];            
    //     }
    // }

    // [Symbol.iterator]() {
    //     const self = this;
    //     let i = 0;

    //     return {
    //         next() {
    //             let v, d = true;

    //             if (self._data[i] !== undefined) {
    //                 v = self._data[i];
    //                 d = false;
    //                 i += 1;
    //             }

    //             return {
    //                 value: v,
    //                 done: d
    //             };
    //         }
    //     }
    // }
}

var q1 = new Queue();
q1.push(10);
q1.push(20);
q1.push(30);

for (const item of q1) {
    console.log(item);
}

// let createIterator = function (arr) {
//     let current = 0;

//     return {
//         next: function () {
//             return current < arr.length ? {
//                 value: arr[current++],
//                 done: false
//             } :
//                 {
//                     done: true
//                 };
//         }
//     };
// }

// var numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9];

// let numberIterator = createIterator(numbers);

// while (true) {
//     let { value, done } = numberIterator.next();
//     if (done) break;
//     console.log(value);
// }