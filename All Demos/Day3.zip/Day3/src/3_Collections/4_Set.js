var set = new Set();

// set.add(1);
// set.add(2);
// set.add(2);
// set.add(4);

var obj = { id: 2 };

set.add({ id: 1 });
set.add(obj);
set.add(obj);
set.add({ id: 4 });

for (const item of set) {
    console.log(item);
}