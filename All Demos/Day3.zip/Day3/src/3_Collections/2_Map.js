var myMap = new Map();
// console.log(myMap);
// console.log(typeof myMap);

var strKey = 'the string';
var objKey = {};
var fnKey = function () { };

myMap.set(strKey, "This is a value for string key");
myMap.set(objKey, "This is a value for object key");
myMap.set(fnKey, "This is a value for function key");

// console.log(myMap.size);
// for (const pair of myMap) {
//     console.log(pair);
// }

// for (const [key, value] of myMap) {
//     console.log(key + "\t" + value);
// }

// for (const [key, value] of myMap.entries()) {
//     console.log(key + "\t" + value);
// }

// for (const key of myMap.keys()) {
//     console.log(key);
// }

for (const value of myMap.values()) {
    console.log(value);
}