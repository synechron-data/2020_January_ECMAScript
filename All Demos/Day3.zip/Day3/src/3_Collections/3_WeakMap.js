// var wm = new WeakMap();

// var o1 = {};
// var o2 = { id: 1 };

// wm.set(o1, "Hello There");
// wm.set(o2, "This is Window");

// // wm is not iterable - Error
// // for (const pair of wm) {
// //     console.log(pair);
// // }

// console.log(wm.get(o1));
// console.log(wm.get(o2));

var map = new Map();
var wmap = new WeakMap();

(function () {
    var a = { x: 1 };
    var b = { y: 2 };

    map.set(a, 1);
    wmap.set(b, 2);
})();

// var a = { x: 1 };
// var b = { y: 2 };

// map.set(a, 1);
// wmap.set(b, 2);