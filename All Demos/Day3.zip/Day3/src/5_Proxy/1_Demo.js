// The Proxy object is used to define custom behavior for fundamental operations 
// (e.g. property lookup, assignment, enumeration, function invocation, etc).

var person = { age: 28 };

var validator = {
    set: function (target, key, value) {
        if (key === 'age') {
            if ((typeof value !== "number" || Number.isNaN(value))) {
                throw 'Age must be a number';
            }
        }

        target[key] = value;
    },
    get: function (target, key, reciever) {

    },
    has: function (target, key) {

    },
    construct(target, args) {

    }
};

// person.age = "Hi";
var personProxy = new Proxy(person, validator);
personProxy.age = "Hi";
console.log(person);
console.log(personProxy);