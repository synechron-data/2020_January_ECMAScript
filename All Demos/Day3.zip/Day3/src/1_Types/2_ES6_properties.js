class Person {
    constructor(name) {
        this._name = name;
        this._age = 0;
    }

    set Name(name) {
        this._name = name;
    }

    get Name() {
        return this._name;
    }

    set Age(age) {
        this._age = age;
    }

    get Age() {
        return this._age;
    }
}

var p1 = new Person("Manish");
console.log(p1.Name + "\t" + p1.Age);
p1.Name = "Abhijeet";
p1.Age = 35;
console.log(p1.Name + "\t" + p1.Age);