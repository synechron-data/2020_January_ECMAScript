var Person = (function () {
    function Person(name) {
        this._name = name;
        this._age = 0;
    }

    Object.defineProperty(Person.prototype, "Name", {
        get: function () {
            return this._name;
        },
        set: function (value) {
            this._name = value;
        },
        enumerable: true
    });

    Object.defineProperty(Person.prototype, "Age", {
        get: function () {
            return this._age;
        },
        set: function (value) {
            this._age = value;
        },
        enumerable: true
    });

    return Person;
})();

var p1 = new Person("Manish");
// console.log(p1.Name + "\t" + p1.Age);
// p1.Name = "Abhijeet";
// p1.Age = 35;
// console.log(p1.Name + "\t" + p1.Age);

// var p2 = new Person("Subodh");
// console.log(p2.getName());
// p2.setName("Ramakant");
// console.log(p2.getName());

for (const key in p1) {
    // console.log(key);
    console.log(p1[key]);
}