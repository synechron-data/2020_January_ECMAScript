// function hello(name) {
//     console.log("Hello,", name);
// }

// hello("Synechron");
// hello("Synechron", "Pune");
// hello();

// ------------------------------------ Handling Less Paramaters

// function add(x, y) {
//     x = x || 0;
//     y = y || 0;

//     if ((typeof x == "number") && (typeof y == "number"))
//         return x + y;

//     throw Error("Invalid Parameters");
// }

// ES 2015 - Default Parameters

// function add(x = 0, y = 0) {
//     if ((typeof x == "number") && (typeof y == "number"))
//         return x + y;

//     throw Error("Invalid Parameters");
// }

// console.log(add(2, 3));
// console.log(add(2));
// console.log(add());
// try {
//     console.log(add(2, "ABC"));
// } catch (e) {
//     console.log(e.message);
// }
// console.log(add(24, 35));

// ------------------------------------ Handling Extra Paramaters

// function Check(name) {
//     console.log(name);
//     console.log(arguments);
// }

// Check("ABC");
// Check("ABC", 20);
// Check("ABC", "XYZ", 20, 30);

// ES2015 - Rest Parameters
// function Check(name, ...args) {
//     console.log(name);
//     console.log(args);
// }

// Check("ABC");
// Check("ABC", 20);
// Check("ABC", "XYZ", 20, 30);

function average(...args) {
    // console.log(args);
    var sum = 0;
    for (let i = 0; i < args.length; i++) {
        sum += args[i];
    }

    if (args.length)
        return sum / args.length;
    else
        return 0;
}

console.log(average());
console.log(average(1));
console.log(average(1, 2));
console.log(average(1, 2, 3, 4, 5));
console.log(average(1, 2, 3, 4, 5, 6, 7, 8, 9));

var arr = [1, 2, 3, 4, 5, 6, 7, 8, 9];
console.log(average(...arr));   // Array Spread (Spread Operator)
