// Fn Declaration Syntax
// function hello() {
//     console.log("Hello from JS Function");
// }

// hello();

// Fn Expression Syntax
// var i = 10;

// var hello = function () {
//     console.log("Hello from JS Function")
// };
// hello();

// Fn Contructor Syntax
// var hello = new Function('console.log("Hello from JS Function")');
// hello();

// 

var i = 10;
var hello = function () {
    console.log("Hello from JS Function")
};

console.log(hello);
console.log(typeof hello);
