// function hello() {
//     console.log("Hello World!");
// }

// function hello(name) {
//     console.log("Hello,", name);
// }

// hello();
// hello("Manish");

// function hello() {
//     function M1() {
//         console.log("Hello World!");
//     }

//     function M2(name) {
//         console.log("Hello,", name);
//     }

//     if (arguments.length == 0)
//         M1();
//     else if (arguments.length == 1)
//         M2(arguments[0]);
//     else
//         throw Error("Invalid Arguments...");
// }

// var hello = (function () {
//     function M1() {
//         console.log("Hello World!");
//     }

//     function M2(name) {
//         console.log("Hello,", name);
//     }

//     return function () {
//         if (arguments.length == 0)
//             M1();
//         else if (arguments.length == 1)
//             M2(arguments[0]);
//         else
//             throw Error("Invalid Arguments...");
//     };
// })();

// hello();
// hello("Manish");

// ------------------------------- Add Assignment

var Add = (function () {
    function M1(x, y) {
        return x + y;
    }

    function M2(x, y, z) {
        return x + y + z;
    }

    return function () {
        if (arguments.length == 2)
            return M1(arguments[0], arguments[1]);
        else if (arguments.length == 3)
            return M2(arguments[0], arguments[1], arguments[2]);
        else
            throw Error("Invalid Arguments...");
    };
})();

console.log(Add(2, 3));
console.log(Add(2, 3, 4));