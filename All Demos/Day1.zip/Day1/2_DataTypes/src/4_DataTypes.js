'use strict'

// var language;
// console.log("Language is " + language);
// console.log("Type of Language is " + typeof language);

// language = null;
// console.log("Language is " + language);
// console.log("Type of Language is " + typeof language);

// // language = 10;
// language = 10.5;
// console.log("Language is " + language);
// console.log("Type of Language is " + typeof language);

// // language = "JavaScript";
// language = 'JavaScript';
// console.log("Language is " + language);
// console.log("Type of Language is " + typeof language);

// language = true;
// console.log("Language is " + language);
// console.log("Type of Language is " + typeof language);

// language = Symbol("Manish");
// console.log("Language is " + language.toString());
// console.log("Type of Language is " + typeof language);

// var color1 = "red";
// var color2 = "red";

// var color1 = { value: "red" };
// var color2 = { value: "red" };

const color1 = "red";
const color2 = "red";

// var color1 = Symbol("red");
// var color2 = Symbol("red");

console.log(color1 == color2);
// console.log(color1.toString() == color2.toString());
console.log(color1 === color2);