'use strict'
// a = 20;
// console.log(a);

// function Check(){
//     // var a = 10;
//     a = 10;
//     console.log("Inside Fn, a is", a);
// }

// Check();
// console.log("Outside Fn, a is", a);

// var a = 10;
// var a = "ABC";

// console.log(a);

var i = "Manish";
console.log("Before, i is", i);

// for (var i = 0; i < 5; i++) {
//     console.log("Inside, i is", i);
// }

// for (var _i = 0; _i < 5; _i++) {
//     console.log("Inside, i is", _i);
// }

// IIFE
(function () {
    for (var i = 0; i < 5; i++) {
        console.log("Inside, i is", i);
    }
})();

console.log("After, i is", i);