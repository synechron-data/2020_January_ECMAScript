'use strict'
// const env = "prod";
// console.log(env);

// env = "dev";
// console.log(env);

// if (true) {
//     const env = "dev";
//     console.log(env);
// }

const obj = { id: 1, name: "Manish" };
console.log(obj);

obj.id = 100;
// obj = {};
console.log(obj);
