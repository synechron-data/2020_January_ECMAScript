// console.log("Hello from JavaScript File");

// Add Function
function Add(number1, number2){
    var sum = number1 + number2;
    return sum;
}