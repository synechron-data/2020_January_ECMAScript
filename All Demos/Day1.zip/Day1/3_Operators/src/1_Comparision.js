'use strict'
var a = 45;
var b = "45";

var result = a == b;    //Abstract Equality
// console.log(result);

var result = a === b;   //Strict Equality
// console.log(result);

var obj1 = {};
var obj2 = {};
var obj3 = obj1;
obj3.id = 1;

// console.log(obj1 == obj2);
// console.log(obj1 === obj2);
console.log(obj3 == obj1);
console.log(obj3 === obj1);

console.log(obj1);
console.log(obj3);
