// var data = "23.5asdasd";

// // var a1 = data + 10;
// // console.log(a1);

// var a1 = parseInt(data) + 10;
// console.log(a1);

// a1 = parseFloat(data) + 10;
// console.log(a1);

// a1 = Number(data) + 10;
// console.log(a1);

// // var flag = true;
// // console.log(flag + 10);

// // var r1 = Number(flag);

// // var obj = null;
// var obj;

// // if (obj == null)
// if (!obj) {
//     console.log("Is Null");
// } else {
//     console.log("Is Not Null");
// }

// console.log(Boolean(1));
// console.log(Boolean(0));
// console.log(Boolean(-1));
// console.log(Boolean("ABC"));
// console.log(Boolean(""));
// console.log(Boolean(null));
// console.log(Boolean(undefined));

// console.log(true && "ABC");
console.log(true && "ABC" || "XYZ");
console.log(false && "ABC" || "XYZ");

{/* <h1 class={{isSelected() && "abc" || "xyz" }}></h1> */}