// const color = "red";
// const c = "red";

// function test(str) {
//     console.log(str === color);
// }

// test(color);
// test(c);
// test("red");

// // ----------------------
// const color1 = { color: "red" };
// const color2 = { color: "red" };

// function test(str) {
//     console.log(str === color1);
// }

// test(color1);
// test(color2);
// test({ color: "red" });

// ---------------------- Symbols
const color1 = Symbol("red");
const color2 = Symbol("red");

function test(str) {
    console.log(str === color1);
}

test(color1);
test(color2);
test(Symbol("red"));