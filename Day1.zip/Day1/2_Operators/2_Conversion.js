// var age = "23.5asdasd";
// console.log("Age is: ", age);

// // var a1 = age + 10;
// // console.log("New Age is: ", a1);

// var a1 = parseInt(age) + 10;
// console.log("New Age is: ", a1);

// var a2 = parseFloat(age) + 10;
// console.log("New Age is: ", a2);

// var a3 = Number(age) + 10;
// console.log("New Age is: ", a3);

// var obj = null;

// if (!obj) {
//     console.log("Is Null");
// } else {
//     console.log("Is not Null");
// }

// console.log(Boolean(1));
// console.log(Boolean(0));
// console.log(Boolean(-1));
// console.log(Boolean("ABC"));
// console.log(Boolean(""));
// console.log(Boolean(undefined));
// console.log(Boolean(null));

console.log(true && "ABC" || "XYZ");

{/* <div class={isSelected() && "ABC" || "XYZ"}>

</div>

<div class={isSelected()}>

</div>

function isSelected() {
    if(true){
        return "ABC";
    } else {
        return "XYZ";
    }
} */}