// var language;
// console.log("Language is: ", language);
// console.log("Type of Language is: ", typeof language);

// language = null;
// console.log("Language is: ", language);
// console.log("Type of Language is: ", typeof language);

// // language = 10;
// language = 10.5;
// console.log("Language is: ", language);
// console.log("Type of Language is: ", typeof language);

// // language = "JavaScript";
// // language = 'JavaScript';
// // Template Literals
// // language = `Java

// //         Script`;

// let a = 10;
// let b = 20;
// // language = "a = " + a + ", b = " + b;
// language = `a = ${a}, 
// b = ${b}`;
// console.log("Language is: ", language);
// console.log("Type of Language is: ", typeof language);

// language = true;
// console.log("Language is: ", language);
// console.log("Type of Language is: ", typeof language);

// language = Symbol("abc");
// console.log("Language is: ", language);
// console.log("Type of Language is: ", typeof language);

let a = "10";
console.log("a is: ", a);
console.log("Type of a is: ", typeof a);

a = String(10);
console.log("a is: ", a);
console.log("Type of a is: ", typeof a);

a = new String(10);
console.log("a is: ", a);
console.log("Type of a is: ", typeof a);