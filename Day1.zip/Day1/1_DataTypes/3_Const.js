// const i = 10;
// i = 20;
// console.log(i);

// const env = "dev";

// if (true) {
//     // env = "prod";
//     const env = "prod";
//     console.log("Inside, env is: ", env);
// }

// console.log("Outside, env is: ", env);

const obj = { id: 1, name: "Manish" };
console.log(obj);
obj.id = 100;
// obj = {};
console.log(obj);
