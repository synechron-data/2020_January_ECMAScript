'use strict'
// a = 10;
// console.log(a);

// function test() {
//     a = 10;
//     console.log("Inside Fn, a is", a);
// }

// test();
// console.log("Outside Fn, a is", a);

// var a = 10;
// console.log(a);

//  Hosting - Hoisting is JavaScript's default behavior of moving declarations to the top.

// a = 10;
// console.log(a);
// var a;

// console.log(a);
// var a = 10;
// console.log(a);

// Scope
// var a = "ABC";
// var a = 10;

var i = "ABC";
console.log("Before, i is", i);

// function loop() {
//     for (var i = 0; i < 5; i++) {
//         console.log("Inside, i is", i);
//     }
// }

// loop();

// IIFE
(function(){
    for (var i = 0; i < 5; i++) {
        console.log("Inside, i is", i);
    }
})();

console.log("After, i is", i);