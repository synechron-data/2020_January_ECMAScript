// Left of EqualTo (Rest)
// Right of EqualTo (Spread)

// Array Spread
// var arr1 = [1, 2, 3, 4, 5];
// // var arr2 = arr1;
// // var arr2 = arr1.slice();
// var arr2 = [...arr1];

// arr2[0] = 100;

// console.log("Array 1", arr1);
// console.log("Array 2", arr2);

// var arr1 = [1, 2];
// var arr2 = [3, 4, 5];
// // var arr3 = [].concat(arr1, arr2);
// var arr3 = [...arr1, ...arr2];

// console.log("Array 1", arr1);
// console.log("Array 2", arr2);
// console.log("Array 3", arr3);

// // ---------------------------------- Array Destructuring
// var arr = [10, 20, 30, 40, 50, 60, 70, 80, 90];

// // var x = arr[0];
// // var y = arr[2];

// // var [x, , y] = arr;
// // console.log(`x = ${x}, y = ${y}`);

// // var [x, , y] = arr;
// // console.log(`Before, x = ${x}, y = ${y}`);

// var [x, y, ...z] = arr;
// console.log(`x = ${x}, y = ${y}`);
// console.log(`z = ${z}`);

// // [x, y] = [y, x];

// // console.log(`After, x = ${x}, y = ${y}`);

// ------------------------------------------------- Object Destructuring

// var p1 = { id: 1, name: "Manish", city: "Pune", state: "MH" };

// // var id = p1.id;
// // var name = p1.name;

// var { id, name } = p1;

// console.log("Id ", id);
// console.log("Name ", name);

// ------------------------------------------------- (Object Rest and Spread - ES 2018)

// var p1 = { id: 1, name: "Manish", city: "Pune", state: "MH" };
// var p2 = p1;

// Shallow Copy
// var p2 = Object.assign({}, p1);  // New Method in ES 2015
// var p2 = { ...p1 };

// p2.name = "Abhijeet";

// console.log("P1 -", p1);
// console.log("P2 -", p2);

// var { id, name, ...address } = p1;

// console.log("Id: ", id);
// console.log("Name: ", name);
// console.log("Address: ", address);

// ------------------------------------------------- SHallow vs Deep Copy

var p1 = { id: 1, name: "Manish", address: { city: "Pune", state: "MH" } };

// var p2 = Object.assign({}, p1);  
// var p2 = { ...p1 };

var p2 = JSON.parse(JSON.stringify(p1));

p2.name = "Abhijeet";
p2.address.city = "Mumbai";

console.log("P1 -", p1);
console.log("P2 -", p2);