// Function Declaration Syntax
// hello();

// function hello() {
//     console.log("Welcome to JS World!");
// }

// Function Expression Syntax
// var hello = function () {
//     console.log("Welcome to JS World!");
// }

// hello();

// Function Constructor Syntax
// const hello = new Function('console.log("Welcome to JS World!");');
// hello();

// ----------------------------------------------

const i = 10;
console.log(i);
console.log(typeof i);

const hello = function () {
    console.log("Welcome to JS World!");
}
console.log(hello);
console.log(typeof hello);