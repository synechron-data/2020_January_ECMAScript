// function hello(name) {
//     if (typeof name != "string")
//         throw Error("Invalid Paramater Type...");

//     console.log("Welcome, ", name.toUpperCase());
//     // console.log("Welcome, ", name);
// }

// try {
//     // hello("Manish");
//     // hello(23);
//     // hello();
//     hello("Manish", "Sharma", "Pune");
// } catch (err) {
//     console.log(err.message);
// }

// ---------------------------------- Handling Less Parameters
// function add(x, y) {
//     x = x || 0;
//     y = y || 0;

//     if (((typeof x) == "number") && ((typeof y) == "number"))
//         return x + y;

//     throw Error("Invalid Paramater Type...");
// }

// ES 2015 - Default Parameters
// function add(x = 0, y = 0) {
//     if (((typeof x) == "number") && ((typeof y) == "number"))
//         return x + y;

//     throw Error("Invalid Paramater Type...");
// }

// console.log(add(2, 4));
// console.log(add(2));
// console.log(add());

// ---------------------------------- Handling Extra Parameters
// function hello(name) {
//     if (typeof name != "string")
//         throw Error("Invalid Paramater Type...");

//     console.log("Welcome, ", name.toUpperCase());
//     console.log(arguments);
// }

// function hello(name, ...args) {
//     if (typeof name != "string")
//         throw Error("Invalid Paramater Type...");

//     console.log("Welcome, ", name.toUpperCase());
//     console.log(arguments);
//     console.log(args);
// }

// hello("Manish");
// hello("Manish", "Pune");
// hello("Manish", "Pune", 411021);

// Rest Parameter
function average(...numbers) {
    // console.log(numbers);
    var sum = 0;

    for (let i = 0; i < numbers.length; i++) {
        sum += numbers[i];
    }

    if (numbers.length)
        return sum / numbers.length;
    else
        return sum;
}

// console.log(average());
// console.log(average(1));
// console.log(average(1, 2));
// console.log(average(1, 2, 3, 4, 5));
// console.log(average(1, 2, 3, 4, 5, 6, 7, 8, 9));


var arr = [1, 2, 3, 4, 5, 6, 7, 8, 9];
console.log(average(...arr));  // Spread Operator