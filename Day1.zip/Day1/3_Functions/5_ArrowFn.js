// function add1(x, y) {
//     return x + y;
// }

// var add2 = function (x, y) {
//     return x + y;
// }

// var add3 = (x, y) => {
//     return x + y;
// }

// var add4 = (x, y) => x + y;

// console.log(add1(2, 3));
// console.log(add2(2, 3));
// console.log(add3(2, 3));
// console.log(add4(2, 3));

// ---------------------------------- Usecase

var employees = [
    { id: 1, name: "Manish", city: "Pune" },
    { id: 2, name: "Neeraj", city: "Delhi" },
    { id: 3, name: "Pravin", city: "Pune" }
];

// var result = [];

// for (let i = 0; i < employees.length; i++) {
//     if (employees[i].city === "Pune")
//         result.push(employees[i]);
// }

// console.log(result);

// // -----------------------------------------
// function filterLogic(item) {
//     return item.city === "Pune";    
// }

// var result = employees.filter(filterLogic);
// console.log(result);

// // -----------------------------------------
// var result = employees.filter(function (item) {
//     return item.city === "Pune";
// });
// console.log(result);

// // -----------------------------------------
// var result = employees.filter((item) => {
//     return item.city === "Pune";
// });
// console.log(result);

// -----------------------------------------
var result = employees.filter(item => item.city === "Pune");
console.log(result);
console.log(employees);