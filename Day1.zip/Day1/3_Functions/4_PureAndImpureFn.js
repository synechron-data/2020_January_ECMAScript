// // ------------------------ With Primitive
// var a = 1;

// function modify(data) {
//     data = 100;
// }

// console.log("Before - ", a);
// modify(a);
// console.log("After - ", a);

// ------------------------ With Complex
// var a = [10, 20, 30];

// function modify(data) {
//     data.push(100);
// }

// console.log("Before - ", a);
// modify(a);
// console.log("After - ", a);

var a = [10, 20, 30];

// Impure Fn
// function insert(dataArr, x) {
//     dataArr[dataArr.length] = x;
//     return dataArr;
// }

// Pure
function insert(dataArr, x) {
    var rArr = [...dataArr];
    rArr[dataArr.length] = x;
    return rArr;
}

console.log("Before - ", a);
var newArr = insert(a, 100);
console.log("Old Array - ", a);
console.log("New Array - ", newArr);